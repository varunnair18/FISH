### Replicating FISH Mask Results - Supplementary Material

The instructions and code for replicating table 1, 2 and figure 2 are in the transformers folder, all other instructions and code for other figures and tables are present in cifar10-fast.
